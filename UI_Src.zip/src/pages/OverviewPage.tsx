import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/card.js';
import { Button } from '../components/ui/button.js';
import { Badge } from '../components/ui/badge.js';
import { ScrollArea } from '../components/ui/scroll-area.js';
import { Alert, AlertDescription } from '../components/ui/alert.js';
import {
  Camera,
  Users,
  Activity,
  AlertTriangle,
  Play,
  Pause,
  RefreshCw,
  Eye,
  EyeOff
} from 'lucide-react';
import { motion } from 'motion/react';
import { surveillanceAPI } from '../services/api';

interface RecognitionHistory {
  id: number;
  name: string;
  confidence: number;
  timestamp: string;
  status: 'authorized' | 'unknown';
  action: string;
}

interface SystemStats {
  cpuUsage: number;
  memoryUsage: number;
  gpuUsage: number;
  diskUsage: number;
  networkUpload: number;
  networkDownload: number;
  fps: number;
  latency: number;
}

interface LiveStats {
  person_count: number;
  known_count: number;
  unknown_count: number;
}

const OverviewPage: React.FC = () => {
  const [recognitionHistory, setRecognitionHistory] = useState<RecognitionHistory[]>([]);
  const [systemStats, setSystemStats] = useState<SystemStats | null>(null);
  const [liveStats, setLiveStats] = useState<LiveStats>({
    person_count: 0,
    known_count: 0,
    unknown_count: 0,
  });
  const [isConnected, setIsConnected] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);
  const [isStreamActive, setIsStreamActive] = useState(false);
  const [showStats, setShowStats] = useState(true);

  const videoRef = useRef<HTMLImageElement>(null);
  const streamIntervalRef = useRef<NodeJS.Timeout | null>(null);
  const statsIntervalRef = useRef<NodeJS.Timeout | null>(null);

  // Camera stream management
  useEffect(() => {
    let mounted = true;

    const startStream = () => {
      if (!videoRef.current || !mounted) return;

      // Stop any existing stream
      stopStream();

      // Start new stream
      videoRef.current.src = 'http://localhost:5000/video_feed';
      setIsStreamActive(true);
      setStreamError(null);
    };

    const stopStream = () => {
      if (videoRef.current) {
        videoRef.current.src = '';
      }
      setIsStreamActive(false);
    };

    const handleLoad = () => {
      if (mounted) {
        setIsConnected(true);
        setStreamError(null);
      }
    };

    const handleError = () => {
      if (mounted) {
        setIsConnected(false);
        setStreamError('Failed to load video stream. Ensure the backend server is running.');
        setIsStreamActive(false);
      }
    };

    // Start stream immediately
    startStream();

    // Add event listeners
    if (videoRef.current) {
      videoRef.current.addEventListener('load', handleLoad);
      videoRef.current.addEventListener('error', handleError);
    }

    // Cleanup function
    return () => {
      mounted = false;
      stopStream();
      if (videoRef.current) {
        videoRef.current.removeEventListener('load', handleLoad);
        videoRef.current.removeEventListener('error', handleError);
      }
    };
  }, [isStreamActive]); // Re-run when isStreamActive changes

  // Fetch recognition history
  useEffect(() => {
    const fetchRecognitionHistory = async () => {
      if (!isConnected) return;

      try {
        const history = await surveillanceAPI.getRecognitionHistory();
        setRecognitionHistory(history);
      } catch (error) {
        console.error('Error fetching recognition history:', error);
      }
    };

    fetchRecognitionHistory();
    const interval = setInterval(fetchRecognitionHistory, 3000); // fetch every 3 seconds
    return () => clearInterval(interval);
  }, [isConnected]);

  // Fetch system stats
  useEffect(() => {
    const fetchSystemStats = async () => {
      try {
        const stats = await surveillanceAPI.getSystemStats();
        setSystemStats(stats);
      } catch (error) {
        console.error('Error fetching system stats:', error);
      }
    };

    fetchSystemStats();
    const interval = setInterval(fetchSystemStats, 5000); // fetch every 5 seconds
    return () => clearInterval(interval);
  }, []);

  // Fetch live stats
  useEffect(() => {
    const fetchLiveStats = async () => {
      try {
        const stats = await surveillanceAPI.getLiveStats();
        setLiveStats(stats);
      } catch (error) {
        console.error('Error fetching live stats:', error);
      }
    };

    fetchLiveStats();
    const interval = setInterval(fetchLiveStats, 2000); // fetch every 2 seconds
    return () => clearInterval(interval);
  }, []);

  const handleToggleStream = () => {
    setIsStreamActive(!isStreamActive);
  };

  const handleRefreshStream = () => {
    setIsStreamActive(false);
    // Stream will restart due to useEffect dependency
    setTimeout(() => setIsStreamActive(true), 100);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between"
        >
          <div>
            <h1 className="text-3xl font-bold">AI Surveillance Overview</h1>
            <p className="text-gray-400 mt-1">Real-time monitoring and face recognition</p>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant={isConnected ? "default" : "destructive"} className="flex items-center space-x-1">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'}`} />
              <span>{isConnected ? 'Connected' : 'Disconnected'}</span>
            </Badge>
          </div>
        </motion.div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Camera Feed */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2"
          >
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Camera className="w-5 h-5 text-blue-400" />
                    <CardTitle>Live Camera Feed</CardTitle>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setShowStats(!showStats)}
                      className="text-gray-400 hover:text-white"
                    >
                      {showStats ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleToggleStream}
                      className="text-gray-400 hover:text-white"
                    >
                      {isStreamActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleRefreshStream}
                      className="text-gray-400 hover:text-white"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="relative aspect-video bg-gray-900 rounded-lg overflow-hidden">
                  {streamError ? (
                    <div className="absolute inset-0 flex items-center justify-center">
                      <Alert className="max-w-md border-red-500/50 bg-red-500/10">
                        <AlertTriangle className="h-4 w-4" />
                        <AlertDescription className="text-red-400">
                          {streamError}
                        </AlertDescription>
                      </Alert>
                    </div>
                  ) : (
                    <img
                      ref={videoRef}
                      alt="Live Camera Feed"
                      className="w-full h-full object-cover"
                      style={{ display: isStreamActive ? 'block' : 'none' }}
                    />
                  )}
                  {!isStreamActive && !streamError && (
                    <div className="absolute inset-0 flex items-center justify-center bg-gray-800">
                      <div className="text-center">
                        <Camera className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-400">Stream paused</p>
                      </div>
                    </div>
                  )}
                  {showStats && isConnected && (
                    <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-sm rounded-lg p-3 text-sm">
                      <div className="space-y-1">
                        <div className="flex items-center space-x-2">
                          <Users className="w-4 h-4 text-blue-400" />
                          <span>Total: {liveStats.person_count}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-green-400 rounded-full" />
                          <span>Known: {liveStats.known_count}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-orange-400 rounded-full" />
                          <span>Unknown: {liveStats.unknown_count}</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Recognition History */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-green-400" />
                  <CardTitle>Recent Recognition Activity</CardTitle>
                </div>
                <CardDescription>Latest face recognition events</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {recognitionHistory.length > 0 ? (
                      recognitionHistory.slice(0, 10).map((person) => (
                        <motion.div
                          key={person.id}
                          initial={{ opacity: 0, x: -20 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg hover:bg-gray-800/50 transition-colors"
                        >
                          <div className="flex items-center space-x-3">
                            <div className={`w-3 h-3 rounded-full ${
                              person.status === 'authorized' ? 'bg-green-400' : 'bg-orange-400'
                            }`} />
                            <div>
                              <p className="text-white text-sm">{person.name}</p>
                              <p className="text-xs text-gray-400">{person.action} • {person.timestamp}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            {person.confidence > 0 && (
                              <p className="text-xs text-green-400">
                                {person.confidence < 0.30 ? 'Low Confidence' : Math.min(Math.round(person.confidence * 100), 100) + '%'}
                              </p>
                            )}
                            <Badge variant={person.status === 'authorized' ? 'default' : 'secondary'} className="text-xs">
                              {person.status === 'authorized' ? 'Known' : 'Unknown'}
                            </Badge>
                          </div>
                        </motion.div>
                      ))
                    ) : (
                      <div className="text-center py-8">
                        <p className="text-gray-400">No recent activity</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* System Stats */}
        {systemStats && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="bg-gray-800/50 border-gray-700">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="w-5 h-5 text-purple-400" />
                  <span>System Performance</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-400">{systemStats.cpuUsage.toFixed(1)}%</div>
                    <div className="text-sm text-gray-400">CPU Usage</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">{systemStats.memoryUsage.toFixed(1)}%</div>
                    <div className="text-sm text-gray-400">Memory</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-400">{systemStats.fps}</div>
                    <div className="text-sm text-gray-400">FPS</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-400">{systemStats.latency}ms</div>
                    <div className="text-sm text-gray-400">Latency</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default OverviewPage;

import { Observable } from 'rxjs';

const API_BASE_URL = 'http://localhost:5000';

export interface DetectionResult {
  person_count: number;
  recognized_faces: string[];
  detections: Detection[];
  total_detections: number;
}

export interface Detection {
  id: number;
  name: string;
  confidence: number;
  detection_confidence: number;
  bbox: number[];
  timestamp: number;
}

export interface SystemStats {
  cpuUsage: number;
  memoryUsage: number;
  gpuUsage: number;
  diskUsage: number;
  networkUpload: number;
  networkDownload: number;
  fps: number;
  latency: number;
}

export interface RecognitionHistory {
  id: number;
  name: string;
  confidence: number;
  timestamp: string;
  status: 'authorized' | 'unknown';
  action: string;
}

export interface LiveStats {
  person_count: number;
  known_count: number;
  unknown_count: number;
}

export interface Person {
  face_id: number;
  name: string;
  enroll: string | null;
  branch: string | null;
  email: string | null;
  contact: string | null;
  image_path: string | null;
  created_at: string;
}

export interface DatabaseStatus {
  total_people: number;
  total_embeddings: number;
  people_list: Person[];
}

export interface AddPersonRequest {
  name: string;
  image: string; // Base64 encoded image
}

export interface AddPersonResponse {
  message: string;
}

export interface RemovePersonRequest {
  face_id: number;
}

export interface RemovePersonResponse {
  message: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  user?: {
    id: string;
    email: string;
    name: string;
  };
}

export interface SignupRequest {
  email: string;
  password: string;
  name: string;
}

export interface SignupResponse {
  success: boolean;
  message: string;
  user?: {
    id: string;
    email: string;
    name: string;
  };
}

class SurveillanceAPI {
  private async request(endpoint: string, options: RequestInit = {}): Promise<any> {
    const url = `${API_BASE_URL}${endpoint}`;
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        const errorMessage = data.error || data.message || `HTTP ${response.status}: ${response.statusText}`;
        throw new Error(errorMessage);
      }

      return data;
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  async detectPerson(imageData: string): Promise<DetectionResult> {
    return this.request('/detect', {
      method: 'POST',
      body: JSON.stringify({ image: imageData }),
    });
  }

  async getSystemStats(): Promise<SystemStats> {
    return this.request('/system-stats');
  }

  async getRecognitionHistory(): Promise<RecognitionHistory[]> {
    return this.request('/recent-recognition');
  }

  async getDatabaseStatus(): Promise<DatabaseStatus> {
    return this.request('/database-status');
  }

  async getLiveStats(): Promise<LiveStats> {
    return this.request('/live-stats');
  }

  async addPerson(formData: FormData): Promise<AddPersonResponse> {
    const url = `${API_BASE_URL}/api/add-person`;
    const response = await fetch(url, {
      method: 'POST',
      body: formData,
    });
    const result = await response.json();
    if (!response.ok) {
      throw new Error(result.error || `HTTP error! status: ${response.status} - ${response.statusText}`);
    }
    return result;
  }

  async removePerson(personData: RemovePersonRequest): Promise<RemovePersonResponse> {
    return this.request('/remove-person', {
      method: 'POST',
      body: JSON.stringify(personData),
    });
  }

  async loginUser(loginData: LoginRequest): Promise<LoginResponse> {
    return this.request('/api/login', {
      method: 'POST',
      body: JSON.stringify(loginData),
    });
  }

  async signupUser(signupData: SignupRequest): Promise<SignupResponse> {
    return this.request('/api/signup', {
      method: 'POST',
      body: JSON.stringify(signupData),
    });
  }

  // Utility method to convert file to base64
  async fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result;
        if (typeof result === 'string') {
          // Remove the data:image/jpeg;base64, prefix
          const parts = result.split(',');
          if (parts.length !== 2) {
            reject(new Error('Invalid base64 data'));
            return;
          }
          const base64 = parts[1];
          if (!base64) {
            reject(new Error('Invalid base64 data'));
            return;
          }
          resolve(base64);
        } else {
          reject(new Error('FileReader result is not a string'));
        }
      };
      reader.onerror = error => reject(error);
    });
  }

  // Video stream handling with reconnection logic
  getVideoStream(): Observable<Blob> {
    return new Observable((observer) => {
      let eventSource: EventSource | null = null;
      let reconnectAttempts = 0;
      const maxReconnectAttempts = 5;
      const reconnectDelay = 2000; // 2 seconds

      const connect = () => {
        if (eventSource) {
          eventSource.close();
        }

        eventSource = new EventSource(`${API_BASE_URL}/video_feed`);

        eventSource.onmessage = (event) => {
          // Reset reconnect attempts on successful message
          reconnectAttempts = 0;
          // Convert the event data to a Blob
          const blob = new Blob([event.data], { type: 'image/jpeg' });
          observer.next(blob);
        };

        eventSource.onopen = () => {
          console.log('Video stream connected');
          reconnectAttempts = 0;
        };

        eventSource.onerror = (error) => {
          console.error('EventSource error:', error);
          eventSource?.close();

          if (reconnectAttempts < maxReconnectAttempts) {
            reconnectAttempts++;
            console.log(`Attempting to reconnect... (${reconnectAttempts}/${maxReconnectAttempts})`);
            setTimeout(connect, reconnectDelay);
          } else {
            console.error('Max reconnection attempts reached');
            observer.error(new Error('Failed to connect to video stream after multiple attempts'));
          }
        };
      };

      // Initial connection
      connect();

      // Cleanup
      return () => {
        if (eventSource) {
          eventSource.close();
        }
      };
    });
  }

  // Utility method to capture camera frame as base64
  async captureCameraFrame(): Promise<string> {
    return new Promise((resolve, reject) => {
      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        reject(new Error('Camera access not supported in this browser'));
        return;
      }

      // Request camera access
      navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        },
        audio: false
      })
      .then((stream) => {
        // Create video element to capture frame
        const video = document.createElement('video');
        video.srcObject = stream;
        video.autoplay = true;
        video.muted = true;

        // Wait for video to load
        video.onloadedmetadata = () => {
          // Create canvas to capture frame
          const canvas = document.createElement('canvas');
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;

          const ctx = canvas.getContext('2d');
          if (!ctx) {
            stream.getTracks().forEach(track => track.stop());
            reject(new Error('Could not get canvas context'));
            return;
          }

          // Draw video frame to canvas
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

          // Convert to base64
          const base64Image = canvas.toDataURL('image/jpeg', 0.8);
          const base64Parts = base64Image.split(',');
          if (base64Parts.length !== 2) {
            stream.getTracks().forEach(track => track.stop());
            reject(new Error('Invalid base64 data from canvas'));
            return;
          }
          const base64Data = base64Parts[1];
          if (!base64Data) {
            stream.getTracks().forEach(track => track.stop());
            reject(new Error('Empty base64 data from canvas'));
            return;
          }

          // Stop camera stream
          stream.getTracks().forEach(track => track.stop());

          // Clean up video element
          video.remove();

          resolve(base64Data);
        };

        video.onerror = () => {
          stream.getTracks().forEach(track => track.stop());
          reject(new Error('Error loading video stream'));
        };
      })
      .catch((error) => {
        console.error('Camera access error:', error);

        // Provide more specific error messages
        if (error.name === 'NotAllowedError') {
          reject(new Error('Camera access denied. Please allow camera permissions.'));
        } else if (error.name === 'NotFoundError') {
          reject(new Error('No camera found on this device.'));
        } else if (error.name === 'NotReadableError') {
          reject(new Error('Camera is being used by another application.'));
        } else {
          reject(new Error(`Camera error: ${error.message}`));
        }
      });
    });
  }
}

export const surveillanceAPI = new SurveillanceAPI();

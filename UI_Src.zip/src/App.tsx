import React, { useState, useEffect, createContext, useContext } from 'react';
import type { ReactNode } from 'react';
import { surveillanceAPI } from './services/api';
import type { DetectionResult, SystemStats, RecognitionHistory, DatabaseStatus, LoginRequest, SignupRequest } from './services/api';
import { motion, AnimatePresence } from 'motion/react';
import { Eye, Shield, Brain, Users, Phone, Mail, MapPin, Menu, X, Lock, User, ArrowRight, Zap, Target, Globe, Database, Camera, UserCheck, Activity, BarChart3, Settings, Power, Maximize2, RefreshCw, Clock, PersonStanding, Monitor, Cpu, HardDrive, Wifi, Download, Upload, FileText, UserPlus, UserMinus, Filter, Search, Calendar, TrendingUp, Layers, ImageIcon, Save, CloudUpload, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from './components/ui/button.js';
import { Input } from './components/ui/input.js';
import { Textarea } from './components/ui/textarea.js';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card.js';
import { Badge } from './components/ui/badge.js';
import { Progress } from './components/ui/progress.js';
import { Alert, AlertDescription, AlertTitle } from './components/ui/alert.js';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs.js';
import { Switch } from './components/ui/switch.js';
import { Separator } from './components/ui/separator.js';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './components/ui/table.js';
import { ScrollArea } from './components/ui/scroll-area.js';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select.js';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from './components/ui/dialog.js';
import { Label } from './components/ui/label.js';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

type Page = 'home' | 'about' | 'contact' | 'login' | 'signup' | 'dashboard';

// Authentication Context Types
interface User {
  id: string;
  email: string;
  name: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (email: string, password: string, name: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for existing session on mount
  useEffect(() => {
    const checkAuth = () => {
      try {
        const storedUser = localStorage.getItem('drishti_user');
        const storedToken = localStorage.getItem('drishti_token');

        if (storedUser && storedToken) {
          setUser(JSON.parse(storedUser));
        }
      } catch (error) {
        console.error('Error checking auth:', error);
        localStorage.removeItem('drishti_user');
        localStorage.removeItem('drishti_token');
      } finally {
        setIsLoading(false);
      }
    };

    checkAuth();
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const response = await surveillanceAPI.loginUser({ email, password });

      if (response.success) {
        const userData: User = {
          id: email, // Use email as ID since API doesn't return user object
          email,
          name: email.split('@')[0] || email // Extract name from email, fallback to email if no @
        };

        setUser(userData);
        localStorage.setItem('drishti_user', JSON.stringify(userData));
        localStorage.setItem('drishti_token', 'dummy-token'); // API doesn't return token
      } else {
        throw new Error(response.message || 'Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (email: string, password: string, name: string) => {
    setIsLoading(true);
    try {
      const response = await surveillanceAPI.signupUser({ email, password, name });

      if (response.success) {
        const userData: User = {
          id: email, // Use email as ID since API doesn't return user object
          email,
          name: name // Use the provided name
        };

        setUser(userData);
        localStorage.setItem('drishti_user', JSON.stringify(userData));
        localStorage.setItem('drishti_token', 'dummy-token'); // API doesn't return token
      } else {
        throw new Error(response.message || 'Signup failed');
      }
    } catch (error) {
      console.error('Signup error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('drishti_user');
    localStorage.removeItem('drishti_token');
  };

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    signup,
    logout
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

const FloatingParticles = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none">
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-blue-500/30 rounded-full"
          initial={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          animate={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
          }}
          transition={{
            duration: Math.random() * 10 + 10,
            repeat: Infinity,
            repeatType: "reverse",
          }}
        />
      ))}
    </div>
  );
};

const Navigation = ({ currentPage, setCurrentPage, mobileMenuOpen, setMobileMenuOpen }: {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}) => {
  const navItems = [
    { id: 'home' as Page, label: 'Home', icon: Eye },
    { id: 'about' as Page, label: 'About', icon: Brain },
    { id: 'contact' as Page, label: 'Contact', icon: Phone },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/80 backdrop-blur-md border-b border-blue-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center space-x-2"
          >
            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center">
              <Eye className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl text-white">Drishti</span>
          </motion.div>

          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-md transition-colors ${
                  currentPage === item.id
                    ? 'text-blue-400 bg-blue-500/10'
                    : 'text-gray-300 hover:text-white'
                }`}
              >
                <item.icon className="h-4 w-4" />
                <span>{item.label}</span>
              </button>
            ))}
            <Button
              onClick={() => setCurrentPage('login')}
              variant="outline"
              className="border-blue-500/50 text-blue-400 hover:bg-blue-500/10"
            >
              <Lock className="h-4 w-4 mr-2" />
              Admin
            </Button>
          </div>

          <button
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-black/90 backdrop-blur-md"
          >
            <div className="px-4 py-4 space-y-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setCurrentPage(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`flex items-center space-x-2 w-full px-3 py-2 rounded-md transition-colors ${
                    currentPage === item.id
                      ? 'text-blue-400 bg-blue-500/10'
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.label}</span>
                </button>
              ))}
              <Button
                onClick={() => {
                  setCurrentPage('login');
                  setMobileMenuOpen(false);
                }}
                variant="outline"
                className="w-full border-blue-500/50 text-blue-400 hover:bg-blue-500/10"
              >
                <Lock className="h-4 w-4 mr-2" />
                Admin Login
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const HomePage = () => {
  const features = [
    {
      icon: Eye,
      title: 'Real-Time Detection',
      description: 'Advanced YOLOv8 technology for instant person detection and counting'
    },
    {
      icon: Shield,
      title: 'Privacy Protected',
      description: 'Unknown individuals labeled as "Unknown" without storing personal data'
    },
    {
      icon: Brain,
      title: 'AI Recognition',
      description: 'DeepFace integration for accurate facial recognition of known individuals'
    },
    {
      icon: Target,
      title: 'Live Analytics',
      description: 'Real-time crowd monitoring and comprehensive analytics'
    }
  ];

  const stats = [
    { number: '99.8%', label: 'Detection Accuracy' },
    { number: '< 50ms', label: 'Response Time' },
    { number: '24/7', label: 'Monitoring' },
    { number: '100%', label: 'Privacy Safe' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-blue-900">
      <div className="pt-16">
        {/* Hero Section */}
        <section className="relative overflow-hidden py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="text-center">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Badge className="mb-4 bg-blue-500/20 text-blue-400 border-blue-500/30">
                  AI-Powered Surveillance
                </Badge>
                <h1 className="text-5xl md:text-7xl mb-6 bg-gradient-to-r from-white via-blue-200 to-cyan-400 bg-clip-text text-transparent">
                  Drishti
                </h1>
                <p className="text-xl md:text-2xl mb-8 text-gray-300 max-w-3xl mx-auto">
                  Intelligent Surveillance System for Real-time Headcount and Recognition
                </p>
                <p className="text-lg mb-12 text-gray-400 max-w-2xl mx-auto">
                  Advanced AI technology combining YOLOv8 detection and DeepFace recognition 
                  for comprehensive security monitoring and analytics with privacy protection.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="flex flex-col sm:flex-row gap-4 justify-center"
              >
                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700">
                  <Zap className="h-5 w-5 mr-2" />
                  View Demo
                </Button>
                <Button size="lg" variant="outline" className="border-blue-500/50 text-blue-400 hover:bg-blue-500/10">
                  <ArrowRight className="h-5 w-5 mr-2" />
                  Learn More
                </Button>
              </motion.div>
            </div>
          </div>

          {/* Animated Background Elements */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
          </div>
        </section>

        {/* Stats Section */}
        <section className="py-16 px-4">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="text-3xl md:text-4xl text-blue-400 mb-2">{stat.number}</div>
                  <div className="text-gray-400">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl mb-4 text-white">Advanced AI Features</h2>
              <p className="text-xl text-gray-400">Cutting-edge technology for comprehensive surveillance</p>
            </motion.div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Card className="bg-gray-900/50 border-gray-800 hover:border-blue-500/50 transition-all duration-300 hover:bg-gray-900/70">
                    <CardHeader>
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center mb-4">
                        <feature.icon className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle className="text-white">{feature.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <CardDescription className="text-gray-400">
                        {feature.description}
                      </CardDescription>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Tech Stack Section */}
        <section className="py-20 px-4 bg-gray-900/30">
          <div className="max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center mb-16"
            >
              <h2 className="text-4xl mb-4 text-white">Powered by Advanced AI</h2>
              <p className="text-xl text-gray-400">Built with cutting-edge machine learning technologies</p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="bg-gradient-to-br from-blue-900/30 to-cyan-900/30 border-blue-500/30">
                <CardHeader>
                  <CardTitle className="text-blue-400">YOLOv8 Detection</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    State-of-the-art object detection for real-time person identification and counting
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-purple-400">DeepFace Recognition</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Advanced facial recognition technology for accurate identification of known individuals
                  </p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-900/30 to-teal-900/30 border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-green-400">Real-time Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    Live dashboard with instant alerts and comprehensive monitoring capabilities
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};

const AboutPage = () => {
  const objectives = [
    'Real-time person detection and counting using YOLOv8',
    'Advanced facial recognition with privacy protection',
    'Comprehensive analytics and data visualization',
    'Secure database for authorized personnel data',
    'Intuitive dashboard for monitoring and analytics',
    'Scalable architecture for future enhancements'
  ];

  const technologies = [
    { name: 'YOLOv8', description: 'Object Detection', color: 'from-blue-500 to-cyan-500' },
    { name: 'DeepFace', description: 'Facial Recognition', color: 'from-purple-500 to-pink-500' },
    { name: 'OpenCV', description: 'Computer Vision', color: 'from-green-500 to-teal-500' },
    { name: 'Python', description: 'Backend Processing', color: 'from-yellow-500 to-orange-500' },
    { name: 'React', description: 'Frontend Interface', color: 'from-indigo-500 to-blue-500' },
    { name: 'MongoDB', description: 'Database Storage', color: 'from-gray-500 to-gray-600' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-purple-900 pt-16">
      <div className="max-w-7xl mx-auto px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl mb-6 bg-gradient-to-r from-white via-purple-200 to-pink-400 bg-clip-text text-transparent">
            About Drishti
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            An intelligent AI-based smart surveillance system designed to revolutionize security monitoring
            through advanced computer vision and machine learning technologies.
          </p>
        </motion.div>

        {/* Project Overview */}
        <section className="mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-2xl text-white flex items-center">
                  <Brain className="h-6 w-6 mr-3 text-purple-400" />
                  Project Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="text-gray-300 space-y-4">
                <p>
                  Drishti addresses the limitations of traditional CCTV systems by integrating artificial intelligence
                  for real-time analysis, detection, and comprehensive monitoring. Our system utilizes YOLOv8 for accurate
                  person detection and DeepFace for facial recognition while maintaining strict privacy standards.
                </p>
                <p>
                  The system provides dynamic crowd analysis, real-time analytics, and maintains a comprehensive dashboard 
                  for security personnel to monitor multiple parameters simultaneously with detailed insights and 
                  performance metrics.
                </p>
              </CardContent>
            </Card>
          </motion.div>
        </section>

        {/* Objectives */}
        <section className="mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h2 className="text-3xl mb-8 text-white text-center">Project Objectives</h2>
            <div className="grid md:grid-cols-2 gap-6">
              {objectives.map((objective, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className="flex items-center space-x-3 p-4 bg-gray-900/30 rounded-lg border border-gray-800"
                >
                  <div className="w-2 h-2 bg-purple-400 rounded-full flex-shrink-0" />
                  <span className="text-gray-300">{objective}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* Technology Stack */}
        <section className="mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-3xl mb-8 text-white text-center">Technology Stack</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {technologies.map((tech, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                >
                  <Card className="bg-gray-900/50 border-gray-800 hover:border-purple-500/50 transition-all duration-300">
                    <CardHeader>
                      <div className={`w-full h-2 bg-gradient-to-r ${tech.color} rounded-full mb-4`} />
                      <CardTitle className="text-white">{tech.name}</CardTitle>
                      <CardDescription className="text-gray-400">{tech.description}</CardDescription>
                    </CardHeader>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </section>

        {/* Team Section */}
        <section>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <h2 className="text-3xl mb-8 text-white text-center">Development Team</h2>
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-xl text-white">Computer Science & Engineering Students</CardTitle>
                <CardDescription className="text-gray-400">
                  Acropolis Institute of Technology and Research, RGPV Bhopal
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4 text-gray-300">
                  <div>
                    <p>• Riya Kaushal (0827CS221230)</p>
                    <p>• Reeti Shrimal (0827CS221223)</p>
                  </div>
                  <div>
                    <p>• Priyal Kaushal (0827CS221200)</p>
                    <p>• Mandisha Mirza (0827CS233D14)</p>
                  </div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-800">
                  <p className="text-gray-300">
                    <strong className="text-white">Supervisor:</strong> Prof. Akshay Dubey
                  </p>
                  <p className="text-gray-400 mt-2">Project Duration: July - December 2025</p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </section>
      </div>
    </div>
  );
};

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log('Form submitted:', formData);
  };

  const contactInfo = [
    {
      icon: Mail,
      title: 'Email',
      details: ['drishti.surveillance@example.com', 'support@drishti.ai'],
      color: 'text-blue-400'
    },
    {
      icon: Phone,
      title: 'Phone',
      details: ['+91 12345 67890', '+91 98765 43210'],
      color: 'text-green-400'
    },
    {
      icon: MapPin,
      title: 'Address',
      details: ['Acropolis Institute of Technology', 'Bhopal, Madhya Pradesh, India'],
      color: 'text-purple-400'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-green-900 pt-16">
      <div className="max-w-7xl mx-auto px-4 py-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-5xl mb-6 bg-gradient-to-r from-white via-green-200 to-cyan-400 bg-clip-text text-transparent">
            Contact Us
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Get in touch with our team to learn more about Drishti AI surveillance system
            or discuss potential collaborations and implementations.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
          >
            <h2 className="text-3xl mb-8 text-white">Get In Touch</h2>
            <div className="space-y-6">
              {contactInfo.map((info, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                >
                  <Card className="bg-gray-900/50 border-gray-800 hover:border-green-500/50 transition-all duration-300">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className={`p-3 rounded-lg bg-gray-800 ${info.color}`}>
                          <info.icon className="h-6 w-6" />
                        </div>
                        <div>
                          <h3 className="text-lg text-white mb-2">{info.title}</h3>
                          {info.details.map((detail, i) => (
                            <p key={i} className="text-gray-400">{detail}</p>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mt-8"
            >
              <Card className="bg-gradient-to-r from-gray-900/50 to-green-900/30 border-green-500/30">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Globe className="h-5 w-5 mr-2 text-green-400" />
                    Academic Project
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300">
                    This project is developed as part of the Bachelor of Technology program in
                    Computer Science and Engineering at Acropolis Institute of Technology and Research,
                    affiliated with Rajiv Gandhi Proudyogiki Vishwavidyalaya, Bhopal.
                  </p>
                </CardContent>
              </Card>
            </motion.div>
          </motion.div>

          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-2xl text-white">Send Message</CardTitle>
                <CardDescription className="text-gray-400">
                  We'd love to hear from you. Send us a message and we'll respond as soon as possible.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="text-white mb-2 block">Name</label>
                      <Input
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="bg-gray-800 border-gray-700 text-white"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <label className="text-white mb-2 block">Email</label>
                      <Input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="bg-gray-800 border-gray-700 text-white"
                        placeholder="your.email@example.com"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-white mb-2 block">Subject</label>
                    <Input
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="bg-gray-800 border-gray-700 text-white"
                      placeholder="Subject of your message"
                    />
                  </div>
                  <div>
                    <label className="text-white mb-2 block">Message</label>
                    <Textarea
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="bg-gray-800 border-gray-700 text-white min-h-32"
                      placeholder="Your message..."
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-green-600 to-cyan-600 hover:from-green-700 hover:to-cyan-700"
                  >
                    <Mail className="h-4 w-4 mr-2" />
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

const LoginPage = ({ setCurrentPage }: { setCurrentPage: (page: Page) => void }) => {
  const { login, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const [errors, setErrors] = useState<{ email?: string; password?: string; general?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateForm = () => {
    const newErrors: { email?: string; password?: string } = {};

    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    try {
      await login(formData.email, formData.password);
      setCurrentPage('dashboard');
    } catch (error) {
      setErrors({
        general: error instanceof Error ? error.message : 'Login failed. Please try again.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-red-900 pt-16 flex items-center justify-center">
      <div className="w-full max-w-md px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="w-16 h-16 bg-gradient-to-r from-red-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-4">
            <Lock className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl text-white mb-2">Admin Login</h1>
          <p className="text-gray-400">Access the Drishti surveillance dashboard</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              {errors.general && (
                <Alert className="mb-4 border-red-500/50 bg-red-500/10">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-red-400">
                    {errors.general}
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="text-white mb-2 block">Email</label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className={`bg-gray-800 border-gray-700 text-white ${errors.email ? 'border-red-500' : ''}`}
                    placeholder="admin@drishti.ai"
                    disabled={isSubmitting}
                  />
                  {errors.email && (
                    <p className="text-red-400 text-sm mt-1">{errors.email}</p>
                  )}
                </div>
                <div>
                  <label className="text-white mb-2 block">Password</label>
                  <Input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className={`bg-gray-800 border-gray-700 text-white ${errors.password ? 'border-red-500' : ''}`}
                    placeholder="••••••••"
                    disabled={isSubmitting}
                  />
                  {errors.password && (
                    <p className="text-red-400 text-sm mt-1">{errors.password}</p>
                  )}
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700"
                  disabled={isSubmitting || isLoading}
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Signing In...
                    </>
                  ) : (
                    <>
                      <Lock className="h-4 w-4 mr-2" />
                      Sign In
                    </>
                  )}
                </Button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-gray-400">
                  Don't have an account?{' '}
                  <button
                    onClick={() => setCurrentPage('signup')}
                    className="text-red-400 hover:text-red-300 transition-colors"
                    disabled={isSubmitting}
                  >
                    Sign up
                  </button>
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

// Add Person Modal Component
const AddPersonModal = ({ isOpen, onClose, onSubmit }: {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (personData: any) => void;
}) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    studentId: '',
    role: 'student',
    department: '',
    year: '',
    phone: '',
    photo: null as File | null
  });
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData({ ...formData, photo: file });
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Create FormData to send multipart data
      const formDataToSend = new FormData();
      formDataToSend.append('name', formData.name);
      formDataToSend.append('enroll', formData.studentId); // Map studentId to enroll
      formDataToSend.append('branch', formData.department); // Map department to branch
      formDataToSend.append('email', formData.email);
      formDataToSend.append('contact', formData.phone); // Map phone to contact
      if (formData.photo) {
        formDataToSend.append('image', formData.photo); // Append the file directly
      }

      // Call API to add person with FormData
      const response = await surveillanceAPI.addPerson(formDataToSend);

      console.log('Person added successfully:', response);

      // Call the onSubmit callback with the new person data
      onSubmit({
        ...formData,
        id: Date.now(),
        status: 'active',
        dateAdded: new Date().toISOString().split('T')[0],
        lastSeen: 'Never'
      });

      // Reset form
      setFormData({
        name: '',
        email: '',
        studentId: '',
        role: 'student',
        department: '',
        year: '',
        phone: '',
        photo: null
      });
      setPhotoPreview(null);
      onClose();
    } catch (error) {
      console.error('Error adding person:', error);
      alert('Failed to add person to database. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center text-xl">
            <UserPlus className="h-5 w-5 mr-2 text-green-400" />
            Add New Person to Database
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Register a new person for facial recognition in the surveillance system.
            All fields marked with * are required.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Photo Upload Section */}
          <div className="space-y-4">
            <Label className="text-white">Profile Photo *</Label>
            <div className="flex items-center space-x-6">
              <div className="relative">
                {photoPreview ? (
                  <img
                    src={photoPreview}
                    alt="Preview"
                    className="w-24 h-24 rounded-lg object-cover border-2 border-gray-700"
                  />
                ) : (
                  <div className="w-24 h-24 bg-gray-800 border-2 border-dashed border-gray-600 rounded-lg flex items-center justify-center">
                    <ImageIcon className="h-8 w-8 text-gray-500" />
                  </div>
                )}
              </div>
              <div className="flex-1">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoChange}
                  className="hidden"
                  id="photo-upload"
                  required
                />
                <Label
                  htmlFor="photo-upload"
                  className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer transition-colors"
                >
                  <CloudUpload className="h-4 w-4 mr-2" />
                  Upload Photo
                </Label>
                <p className="text-xs text-gray-400 mt-2">
                  Upload a clear, front-facing photo for best recognition results.
                  Supported formats: JPG, PNG, WebP
                </p>
              </div>
            </div>
          </div>

          <Separator className="bg-gray-700" />

          {/* Personal Information */}
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label className="text-white">Full Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-gray-800 border-gray-700 text-white mt-1"
                placeholder="Enter full name"
                required
              />
            </div>
            <div>
              <Label className="text-white">Email Address *</Label>
              <Input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-gray-800 border-gray-700 text-white mt-1"
                placeholder="student@college.edu"
                required
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label className="text-white">Student/Employee ID *</Label>
              <Input
                value={formData.studentId}
                onChange={(e) => setFormData({ ...formData, studentId: e.target.value })}
                className="bg-gray-800 border-gray-700 text-white mt-1"
                placeholder="ID number"
                required
              />
            </div>
            <div>
              <Label className="text-white">Role *</Label>
              <Select value={formData.role} onValueChange={(value: string) => setFormData({ ...formData, role: value })}>
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student">Student</SelectItem>
                  <SelectItem value="faculty">Faculty</SelectItem>
                  <SelectItem value="staff">Staff</SelectItem>
                  <SelectItem value="security">Security</SelectItem>
                  <SelectItem value="admin">Administrator</SelectItem>
                  <SelectItem value="visitor">Authorized Visitor</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label className="text-white">Department/Course</Label>
              <Input
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="bg-gray-800 border-gray-700 text-white mt-1"
                placeholder="e.g., Computer Science"
              />
            </div>
            <div>
              <Label className="text-white">Year/Position</Label>
              <Input
                value={formData.year}
                onChange={(e) => setFormData({ ...formData, year: e.target.value })}
                className="bg-gray-800 border-gray-700 text-white mt-1"
                placeholder="e.g., 3rd Year, Professor"
              />
            </div>
          </div>

          <div>
            <Label className="text-white">Phone Number</Label>
            <Input
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="bg-gray-800 border-gray-700 text-white mt-1"
              placeholder="+91 12345 67890"
            />
          </div>

          <DialogFooter className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="border-gray-600 text-gray-300 hover:bg-gray-800"
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="bg-green-600 hover:bg-green-700"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <Save className="h-4 w-4 mr-2" />
                  Add to Database
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

const SurveillanceDashboard = ({ setCurrentPage }: { setCurrentPage: (page: Page) => void }) => {
  const [isRecording, setIsRecording] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState('overview');
  const [peopleCount, setPeopleCount] = useState(0);
  const [isAddPersonModalOpen, setIsAddPersonModalOpen] = useState(false);
  const [detectedPeople, setDetectedPeople] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [streamError, setStreamError] = useState<string | null>(null);

  // Live stream states
  const [liveStats, setLiveStats] = useState({ person_count: 0, known_count: 0, unknown_count: 0 });

  const totalPeopleCount = liveStats.person_count;
  const knownPeopleCount = liveStats.known_count;
  const unknownPeopleCount = liveStats.unknown_count;

  // System performance data
  const [systemStats, setSystemStats] = useState<SystemStats>({
    cpuUsage: 0,
    memoryUsage: 0,
    gpuUsage: 0,
    diskUsage: 0,
    networkUpload: 0,
    networkDownload: 0,
    fps: 0,
    latency: 0
  });

  // Recognition history data
  const [recognitionHistory, setRecognitionHistory] = useState<RecognitionHistory[]>([]);

  // Database status
  const [databaseStatus, setDatabaseStatus] = useState<DatabaseStatus>({
    total_people: 0,
    total_embeddings: 0,
    people_list: []
  });



  // Analytics data
  const hourlyData = [
    { time: '09:00', people: 5, recognized: 4 },
    { time: '10:00', people: 12, recognized: 8 },
    { time: '11:00', people: 18, recognized: 14 },
    { time: '12:00', people: 25, recognized: 20 },
    { time: '13:00', people: 22, recognized: 18 },
    { time: '14:00', people: 30, recognized: 24 },
    { time: '15:00', people: 28, recognized: 22 }
  ];

  // Recognition distribution data
  const recognitionDistribution = [
    { name: 'Known People', value: knownPeopleCount, color: '#10b981' },
    { name: 'Unknown People', value: unknownPeopleCount, color: '#f59e0b' }
  ];

  // Database management - fetch real data from backend
  const [databaseUsers, setDatabaseUsers] = useState<any[]>([]);

  const handleAddPerson = (personData: any) => {
    // Refresh database status after adding person
    const fetchUpdatedData = async () => {
      try {
        const status = await surveillanceAPI.getDatabaseStatus();
        setDatabaseStatus(status);

        const users = status.people_list.map((person: any) => ({
          id: person.face_id,
          name: person.name,
          email: person.email,
          studentId: person.enroll,
          role: 'Student',
          department: person.branch,
          status: 'active',
          lastSeen: person.created_at ? new Date(person.created_at).toLocaleString() : 'Never',
          dateAdded: person.created_at ? new Date(person.created_at).toLocaleDateString() : 'Unknown'
        }));
        setDatabaseUsers(users);
      } catch (error) {
        console.error('Error refreshing database after adding person:', error);
      }
    };

    fetchUpdatedData();
  };

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Test connection to backend
  useEffect(() => {
    const testConnection = async () => {
      try {
        const response = await fetch('http://localhost:5000/system-stats');
        if (response.ok) {
          setIsConnected(true);
        }
      } catch (error) {
        console.error('Backend not connected:', error);
        setIsConnected(false);
      }
    };

    testConnection();
    const interval = setInterval(testConnection, 5000); // check every 5 seconds
    return () => clearInterval(interval);
  }, []);

  // Fetch system stats
  useEffect(() => {
    const fetchSystemStats = async () => {
      if (!isConnected) return;

      try {
        const stats = await surveillanceAPI.getSystemStats();
        setSystemStats(stats);
      } catch (error) {
        console.error('Error fetching system stats:', error);
      }
    };

    fetchSystemStats();
    const interval = setInterval(fetchSystemStats, 5000); // fetch every 5 seconds
    return () => clearInterval(interval);
  }, [isConnected]);

  // Fetch recognition history
  useEffect(() => {
    const fetchRecognitionHistory = async () => {
      if (!isConnected) return;

      try {
        const history = await surveillanceAPI.getRecognitionHistory();
        setRecognitionHistory(history);
      } catch (error) {
        console.error('Error fetching recognition history:', error);
      }
    };

    fetchRecognitionHistory();
    const interval = setInterval(fetchRecognitionHistory, 10000); // fetch every 10 seconds
    return () => clearInterval(interval);
  }, [isConnected]);

  // Fetch database status and users
  useEffect(() => {
    const fetchDatabaseStatus = async () => {
      if (!isConnected) return;

      try {
        const status = await surveillanceAPI.getDatabaseStatus();
        setDatabaseStatus(status);

        // Update database users from backend data
        const users = status.people_list.map((person: any, index: number) => ({
          id: person.face_id,
          name: person.name,
          email: person.email,
          studentId: person.enroll,
          role: 'Student', // Default role, could be enhanced
          department: person.branch,
          status: 'active',
          lastSeen: person.created_at ? new Date(person.created_at).toLocaleString() : 'Never',
          dateAdded: person.created_at ? new Date(person.created_at).toLocaleDateString() : 'Unknown'
        }));
        setDatabaseUsers(users);
      } catch (error) {
        console.error('Error fetching database status:', error);
      }
    };

    fetchDatabaseStatus();
    const interval = setInterval(fetchDatabaseStatus, 30000); // fetch every 30 seconds
    return () => clearInterval(interval);
  }, [isConnected]);

  // Setup backend video stream
  useEffect(() => {
    const img = document.getElementById('cameraFeed') as HTMLImageElement;
    const placeholder = document.getElementById('cameraPlaceholder') as HTMLElement;

    if (img && placeholder) {
      img.src = 'http://localhost:5000/video_feed';

      const handleLoad = () => {
        placeholder.style.display = 'none';
        img.style.display = 'block';
        setStreamError(null);
        setError(null);
      };

      const handleError = (e: Event) => {
        console.error('Video stream error:', e);
        setStreamError('Failed to load video stream. Ensure the backend server is running and camera is available.');
        placeholder.style.display = 'flex';
        img.style.display = 'none';
        setIsConnected(false);
      };

      img.addEventListener('load', handleLoad);
      img.addEventListener('error', handleError);

      return () => {
        img.removeEventListener('load', handleLoad);
        img.removeEventListener('error', handleError);
        img.src = '';
      };
    }
  }, []);

  // Poll live stats from backend
  useEffect(() => {
    const fetchLiveStats = async () => {
      try {
        const response = await fetch('http://localhost:5000/live-stats');
        if (response.ok) {
          const data = await response.json();
          setLiveStats(data);
          setPeopleCount(data.person_count);
          setIsConnected(true);
          setStreamError(null);
        } else {
          setIsConnected(false);
        }
      } catch (error) {
        console.error('Error fetching live stats:', error);
        setIsConnected(false);
      }
    };

    fetchLiveStats();
    const interval = setInterval(fetchLiveStats, 2000); // Poll every 2 seconds
    return () => clearInterval(interval);
  }, []);



  const { logout } = useAuth();

  const handleLogout = async () => {
    try {
      logout();
      setCurrentPage('login');
    } catch (error) {
      console.error('Logout error:', error);
      // Force logout even if there's an error
      setCurrentPage('login');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-blue-900 pt-16">
      <div className="max-w-full mx-auto px-4 py-6">
        {/* Enhanced Dashboard Header */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 gap-4">
          <div>
            <h1 className="text-3xl text-white mb-2">Drishti Control Center</h1>
            <p className="text-gray-400">AI-Powered Surveillance & Analytics Dashboard</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="text-right">
              <p className="text-sm text-gray-400">System Time</p>
              <p className="text-white">{currentTime.toLocaleTimeString()}</p>
            </div>
            <Badge className="text-blue-400 bg-blue-500/20 border-blue-500/30">
              <Monitor className="h-3 w-3 mr-1" />
              MONITORING
            </Badge>
            <Button onClick={handleLogout} variant="outline" className="border-red-500/50 text-red-400 hover:bg-red-500/10">
              <Power className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <Alert className="mb-6 border-red-500/50 bg-red-500/10">
            <AlertDescription className="text-red-400">
              {error}
            </AlertDescription>
          </Alert>
        )}

        {/* Connection Status Alert */}
        {!isConnected && (
          <Alert className="mb-6 border-yellow-500/50 bg-yellow-500/10">
            <AlertDescription className="text-yellow-400">
              AI Backend not connected. Please ensure the Python server is running on port 5000.
              <Button
                size="sm"
                variant="outline"
                className="ml-4 border-yellow-500/50 text-yellow-400"
                onClick={() => window.location.reload()}
              >
                Retry Connection
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-gray-800/50 mb-6">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Monitor className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="database" className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              Database
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              {/* Enhanced Live Feed */}
              <div className="xl:col-span-2">
                <Card className="bg-gray-900/50 border-gray-800">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-white flex items-center">
                        <Camera className="h-5 w-5 mr-2 text-blue-400" />
                        Live Camera Feed - Person Detection
                      </CardTitle>
                      <div className="flex items-center space-x-2">
                        <Badge className={`${isConnected ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'}`}>
                          {isConnected ? 'AI CONNECTED' : 'AI DISCONNECTED'}
                        </Badge>
                        <Badge className={`${isRecording ? 'bg-red-500/20 text-red-400' : 'bg-gray-500/20 text-gray-400'}`}>
                          {isRecording ? 'RECORDING' : 'STOPPED'}
                        </Badge>
                        <Badge className="bg-blue-500/20 text-blue-400">
                          {totalPeopleCount} DETECTED
                        </Badge>
                        <div className="flex items-center space-x-2">
                          {streamError ? (
                          <Button
                            size="sm"
                            onClick={() => {
                              const img = document.getElementById('cameraFeed') as HTMLImageElement;
                              if (img) {
                                img.src = '';
                                img.src = 'http://localhost:5000/video_feed';
                              }
                            }}
                            variant="outline"
                            className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10"
                          >
                              <RefreshCw className="h-4 w-4 mr-2" />
                              Reload Stream
                            </Button>
                          ) : null}
                          <Button size="sm" variant="outline" className="border-gray-600">
                            <Maximize2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="relative bg-black rounded-lg aspect-video overflow-hidden">
                      {/* Live Camera Feed from Backend */}
                      <img
                        id="cameraFeed"
                        className="absolute inset-0 w-full h-full object-cover z-10"
                        alt="Live Camera Feed"
                      />

                      {/* Camera feed background - shown when camera not available */}
                      <div
                        id="cameraPlaceholder"
                        className="absolute inset-0 bg-gradient-to-br from-gray-800 via-gray-900 to-black flex items-center justify-center z-0"
                      >
                        <div className="text-center opacity-20">
                          <Camera className="h-20 w-20 text-gray-500 mx-auto mb-4" />
                          <p className="text-gray-500 text-lg">Live Surveillance Feed</p>
                          <p className="text-gray-400 text-sm mt-2">Connecting to camera...</p>
                        </div>
                      </div>
                      
                      {/* Enhanced status overlays */}
                      <div className="absolute top-4 left-4 space-y-2">
                        <div className="bg-black/80 rounded-lg p-3">
                          <div className="flex items-center space-x-2 text-sm mb-2">
                            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                            <span className="text-white">YOLOv8 Detection</span>
                          </div>
                          <div className="flex items-center space-x-2 text-sm">
                            <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse" />
                            <span className="text-white">DeepFace Recognition</span>
                          </div>
                        </div>
                      </div>

                      {/* Performance stats */}
                      <div className="absolute top-4 right-4 bg-black/80 rounded-lg p-3">
                        <div className="text-green-400 text-sm space-y-1">
                          <div className="flex items-center space-x-2">
                            <Activity className="h-3 w-3" />
                            <span>{systemStats.fps} FPS</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Clock className="h-3 w-3" />
                            <span>{systemStats.latency}ms</span>
                          </div>
                        </div>
                      </div>

                      {/* Live stats overlay */}
                      <div className="absolute bottom-4 left-4 bg-black/80 rounded-lg p-3">
                        <div className="text-white text-sm space-y-1">
                          <div className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-green-400 rounded-full" />
                            <span>Known: {knownPeopleCount}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <div className="w-2 h-2 bg-orange-400 rounded-full" />
                            <span>Unknown: {unknownPeopleCount}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Enhanced Monitoring Panel */}
              <div className="space-y-6">
                {/* Overall Status */}
                <Card className="border border-blue-500/30 bg-blue-500/10">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Users className="h-5 w-5 mr-2 text-blue-400" />
                      People Count
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-4xl text-blue-400 mb-2">{totalPeopleCount}</div>
                      <p className="text-sm text-gray-300">
                        Total people detected
                      </p>
                      <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                        <div className="text-green-400">
                          Known: {knownPeopleCount}
                        </div>
                        <div className="text-orange-400">
                          Unknown: {unknownPeopleCount}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Live Statistics */}
                <Card className="bg-gray-900/50 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Activity className="h-5 w-5 mr-2 text-cyan-400" />
                      Live Statistics
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <motion.div
                          key={totalPeopleCount}
                          initial={{ scale: 1.1 }}
                          animate={{ scale: 1 }}
                          className="text-2xl text-blue-400"
                        >
                          {totalPeopleCount}
                        </motion.div>
                        <p className="text-xs text-gray-400">Total People</p>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl text-green-400">
                          {knownPeopleCount}
                        </div>
                        <p className="text-xs text-gray-400">Known People</p>
                      </div>
                    </div>
                    <Separator />
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Recognition Rate</span>
                        <span className="text-green-400">
                          {totalPeopleCount > 0 ? Math.round((knownPeopleCount / totalPeopleCount) * 100) : 0}%
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Unknown People</span>
                        <span className="text-orange-400">{unknownPeopleCount}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Average Confidence</span>
                        <span className="text-white">N/A (Stream Annotated)</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* System Performance */}
                <Card className="bg-gray-900/50 border-gray-800">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center">
                      <Cpu className="h-5 w-5 mr-2 text-orange-400" />
                      System Performance
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">CPU Usage</span>
                        <span className="text-white">{systemStats.cpuUsage}%</span>
                      </div>
                      <Progress value={systemStats.cpuUsage} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">Memory</span>
                        <span className="text-white">{systemStats.memoryUsage}%</span>
                      </div>
                      <Progress value={systemStats.memoryUsage} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-400">GPU Usage</span>
                        <span className="text-white">{systemStats.gpuUsage}%</span>
                      </div>
                      <Progress value={systemStats.gpuUsage} className="h-2" />
                    </div>
                    <Separator />
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div className="flex items-center space-x-1">
                        <Upload className="h-3 w-3 text-green-400" />
                        <span className="text-gray-400">{systemStats.networkUpload} KB/s</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Download className="h-3 w-3 text-blue-400" />
                        <span className="text-gray-400">{systemStats.networkDownload} KB/s</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>

            {/* Quick Recognition Panel */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center justify-between">
                  <div className="flex items-center">
                    <UserCheck className="h-5 w-5 mr-2 text-purple-400" />
                    Recent Recognition Activity
                  </div>
                  <Button size="sm" variant="outline" className="border-gray-600">
                    View All
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-48">
                  <div className="space-y-3">
                    {recognitionHistory.slice(0, 6).map((person) => (
                      <motion.div
                        key={person.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex items-center justify-between p-3 bg-gray-800/30 rounded-lg hover:bg-gray-800/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${
                            person.status === 'authorized' ? 'bg-green-400' : 'bg-orange-400'
                          }`} />
                          <div>
                            <p className="text-white text-sm">{person.name}</p>
                            <p className="text-xs text-gray-400">{person.action} • {person.timestamp}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          {person.confidence > 0 && (
                            <p className="text-xs text-green-400">{person.confidence}%</p>
                          )}
                          <Badge variant={person.status === 'authorized' ? 'default' : 'secondary'} className="text-xs">
                            {person.status === 'authorized' ? 'Known' : 'Unknown'}
                          </Badge>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>



          {/* Enhanced Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-green-400" />
                    Hourly Traffic Pattern
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <AreaChart data={hourlyData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                      <XAxis dataKey="time" stroke="#9CA3AF" />
                      <YAxis stroke="#9CA3AF" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#1F2937', 
                          border: '1px solid #374151',
                          borderRadius: '8px'
                        }} 
                      />
                      <Area 
                        type="monotone" 
                        dataKey="people" 
                        stroke="#3B82F6" 
                        fill="#3B82F6" 
                        fillOpacity={0.3}
                        name="Total People"
                      />
                      <Area 
                        type="monotone" 
                        dataKey="recognized" 
                        stroke="#10B981" 
                        fill="#10B981" 
                        fillOpacity={0.3}
                        name="Recognized"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Users className="h-5 w-5 mr-2 text-purple-400" />
                    Recognition Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={250}>
                    <PieChart>
                      <Pie
                        data={recognitionDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}`}
                      >
                        {recognitionDistribution.map((entry, index) => (
                          <Cell key={index} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-800 lg:col-span-2">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <BarChart3 className="h-5 w-5 mr-2 text-cyan-400" />
                    Daily Analytics Summary
                  </CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="grid md:grid-cols-4 gap-6">
                      <div className="text-center p-4 bg-gray-800/30 rounded-lg">
                        <div className="text-3xl text-blue-400 mb-2">247</div>
                        <p className="text-sm text-gray-400">Total Detections</p>
                        <p className="text-xs text-green-400 mt-1">+12% from yesterday</p>
                      </div>
                      <div className="text-center p-4 bg-gray-800/30 rounded-lg">
                        <div className="text-3xl text-green-400 mb-2">189</div>
                        <p className="text-sm text-gray-400">Recognized Faces</p>
                        <p className="text-xs text-green-400 mt-1">76.5% accuracy</p>
                      </div>
                      <div className="text-center p-4 bg-gray-800/30 rounded-lg">
                        <div className="text-3xl text-orange-400 mb-2">8</div>
                        <p className="text-sm text-gray-400">Crowd Alerts</p>
                        <p className="text-xs text-orange-400 mt-1">Peak: 14:30-15:30</p>
                      </div>
                      <div className="text-center p-4 bg-gray-800/30 rounded-lg">
                        <div className="text-3xl text-purple-400 mb-2">{unknownPeopleCount}</div>
                        <p className="text-sm text-gray-400">Unknown People</p>
                        <p className="text-xs text-orange-400 mt-1">Require attention</p>
                      </div>
                    </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Database Management Tab */}
          <TabsContent value="database" className="space-y-6">
            {/* Database Statistics */}
            <div className="grid md:grid-cols-4 gap-4 mb-6">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Total People</p>
                      <p className="text-2xl text-white">{databaseStatus.total_people}</p>
                    </div>
                    <Users className="h-8 w-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gray-900/50 border-gray-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Face Embeddings</p>
                      <p className="text-2xl text-blue-400">{databaseStatus.total_embeddings}</p>
                    </div>
                    <Brain className="h-8 w-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gray-900/50 border-gray-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">AI Model Status</p>
                      <p className="text-2xl text-green-400">Active</p>
                    </div>
                    <Activity className="h-8 w-8 text-green-400" />
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-gray-900/50 border-gray-800">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-400">Connection</p>
                      <p className={`text-2xl ${isConnected ? 'text-green-400' : 'text-red-400'}`}>
                        {isConnected ? 'Connected' : 'Disconnected'}
                      </p>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${isConnected ? 'bg-green-400' : 'bg-red-400'}`} />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-white flex items-center">
                    <Database className="h-5 w-5 mr-2 text-green-400" />
                    Authorized Personnel Database
                  </CardTitle>
                  <div className="flex space-x-2">
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="border-green-500/50 text-green-400 hover:bg-green-500/10"
                      onClick={() => setIsAddPersonModalOpen(true)}
                    >
                      <UserPlus className="h-4 w-4 mr-2" />
                      Add Person
                    </Button>
                    <Button size="sm" variant="outline" className="border-blue-500/50 text-blue-400">
                      <FileText className="h-4 w-4 mr-2" />
                      Export Data
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-6">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                    <Input 
                      placeholder="Search personnel..." 
                      className="pl-10 bg-gray-800 border-gray-700"
                    />
                  </div>
                  <Select defaultValue="all">
                    <SelectTrigger className="w-40 bg-gray-800">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      <SelectItem value="employee">Employee</SelectItem>
                      <SelectItem value="manager">Manager</SelectItem>
                      <SelectItem value="security">Security</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow className="border-gray-800">
                      <TableHead className="text-gray-400">Name</TableHead>
                      <TableHead className="text-gray-400">ID</TableHead>
                      <TableHead className="text-gray-400">Email</TableHead>
                      <TableHead className="text-gray-400">Role</TableHead>
                      <TableHead className="text-gray-400">Department</TableHead>
                      <TableHead className="text-gray-400">Status</TableHead>
                      <TableHead className="text-gray-400">Last Seen</TableHead>
                      <TableHead className="text-gray-400">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {databaseUsers.map((user) => (
                      <TableRow key={user.id} className="border-gray-800 hover:bg-gray-800/30">
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm">{user.name.split(' ').map((n: string) => n[0]).join('')}</span>
                            </div>
                            <span className="text-white">{user.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-400 font-mono">{user.studentId}</TableCell>
                        <TableCell className="text-gray-400">{user.email}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={
                            user.role === 'Student' ? 'border-blue-500/50 text-blue-400' :
                            user.role === 'Faculty' ? 'border-purple-500/50 text-purple-400' :
                            user.role === 'Admin' ? 'border-red-500/50 text-red-400' :
                            'border-green-500/50 text-green-400'
                          }>
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-gray-400">{user.department}</TableCell>
                        <TableCell>
                          <Badge className={
                            user.status === 'active' ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                          }>
                            {user.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-gray-400">{user.lastSeen}</TableCell>
                        <TableCell>
                          <div className="flex space-x-1">
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-blue-400 hover:text-blue-300"
                              onClick={() => {
                                // View person details (placeholder)
                                console.log('View person:', user.name);
                              }}
                            >
                              <User className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-red-400 hover:text-red-300"
                              onClick={async () => {
                                if (confirm(`Are you sure you want to remove ${user.name} from the database?`)) {
                                  try {
                                    await surveillanceAPI.removePerson({ name: user.name });
                                    // Update database status
                                    const status = await surveillanceAPI.getDatabaseStatus();
                                    setDatabaseStatus(status);
                                    alert(`${user.name} has been removed from the database.`);
                                  } catch (error) {
                                    console.error('Error removing person:', error);
                                    alert('Failed to remove person from database.');
                                  }
                                }
                              }}
                            >
                              <UserMinus className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>



          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Settings className="h-5 w-5 mr-2 text-gray-400" />
                    System Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-white text-sm">Recording</label>
                        <p className="text-xs text-gray-400">Enable video recording</p>
                      </div>
                      <Switch checked={isRecording} onCheckedChange={setIsRecording} />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-white text-sm">Facial Recognition</label>
                        <p className="text-xs text-gray-400">Enable DeepFace recognition</p>
                      </div>
                      <Switch checked={true} />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-white text-sm">Live Analytics</label>
                        <p className="text-xs text-gray-400">Enable real-time data processing</p>
                      </div>
                      <Switch checked={true} />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <label className="text-white text-sm">Data Logging</label>
                        <p className="text-xs text-gray-400">Log detection and recognition data</p>
                      </div>
                      <Switch checked={true} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900/50 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <Brain className="h-5 w-5 mr-2 text-purple-400" />
                    AI Configuration
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-white text-sm mb-2 block">Detection Sensitivity</label>
                    <Input 
                      type="number" 
                      defaultValue="75" 
                      className="bg-gray-800 border-gray-700"
                    />
                    <p className="text-xs text-gray-400 mt-1">Adjustment for YOLOv8 detection sensitivity (0-100)</p>
                  </div>
                  <div>
                    <label className="text-white text-sm mb-2 block">Recognition Confidence</label>
                    <Input 
                      type="number" 
                      defaultValue="85" 
                      className="bg-gray-800 border-gray-700"
                    />
                    <p className="text-xs text-gray-400 mt-1">Minimum confidence percentage for face recognition</p>
                  </div>
                  <div>
                    <label className="text-white text-sm mb-2 block">Processing FPS</label>
                    <Input 
                      type="number" 
                      defaultValue="30" 
                      className="bg-gray-800 border-gray-700"
                    />
                    <p className="text-xs text-gray-400 mt-1">Target frames per second for video processing</p>
                  </div>
                  <Button className="w-full bg-blue-600 hover:bg-blue-700">
                    Save Configuration
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>

        {/* Add Person Modal */}
        <AddPersonModal 
          isOpen={isAddPersonModalOpen}
          onClose={() => setIsAddPersonModalOpen(false)}
          onSubmit={handleAddPerson}
        />
      </div>
    </div>
  );
};

const SignupPage = ({ setCurrentPage }: { setCurrentPage: (page: Page) => void }) => {
  const { signup, isLoading } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [errors, setErrors] = useState<{ name?: string; email?: string; password?: string; confirmPassword?: string; general?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string>('');

  const validateForm = () => {
    const newErrors: { name?: string; email?: string; password?: string; confirmPassword?: string } = {};

    if (!formData.name) {
      newErrors.name = 'Full name is required';
    } else if (formData.name.trim().length < 2) {
      newErrors.name = 'Full name must be at least 2 characters';
    }

    if (!formData.email) {
      newErrors.email = 'Email is required';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters';
    } else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])/.test(formData.password)) {
      newErrors.password = 'Password must contain uppercase, lowercase, number, and special character';
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'Please confirm your password';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    setSuccessMessage('');

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    try {
      await signup(formData.email, formData.password, formData.name);
      setSuccessMessage('Account created successfully! Redirecting to dashboard...');
      setTimeout(() => {
        setCurrentPage('dashboard');
      }, 2000);
    } catch (error) {
      setErrors({
        general: error instanceof Error ? error.message : 'Signup failed. Please try again.'
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-purple-900 pt-16 flex items-center justify-center">
      <div className="w-full max-w-md px-4">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center mx-auto mb-4">
            <User className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-3xl text-white mb-2">Admin Signup</h1>
          <p className="text-gray-400">Create your admin account for Drishti</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="bg-gray-900/50 border-gray-800">
            <CardContent className="p-6">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className="text-white mb-2 block">Full Name</label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className={`bg-gray-800 border-gray-700 text-white ${errors.name ? 'border-red-500' : ''}`}
                    placeholder="Your full name"
                    required
                  />
                  {errors.name && (
                    <p className="text-red-400 text-sm mt-1">{errors.name}</p>
                  )}
                </div>
                <div>
                  <label className="text-white mb-2 block">Email</label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="admin@drishti.ai"
                    required
                  />
                </div>
                <div>
                  <label className="text-white mb-2 block">Password</label>
                  <Input
                    type="password"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <label className="text-white mb-2 block">Confirm Password</label>
                  <Input
                    type="password"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className="bg-gray-800 border-gray-700 text-white"
                    placeholder="••••••••"
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                >
                  <User className="h-4 w-4 mr-2" />
                  Create Account
                </Button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-gray-400">
                  Already have an account?{' '}
                  <button
                    onClick={() => setCurrentPage('login')}
                    className="text-purple-400 hover:text-purple-300 transition-colors"
                  >
                    Sign in
                  </button>
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

const AppContent = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { isAuthenticated, isLoading } = useAuth();

  useEffect(() => {
    document.body.className = 'dark';
  }, []);

  // Route protection: redirect to login if trying to access dashboard without authentication
  useEffect(() => {
    if (!isLoading && currentPage === 'dashboard' && !isAuthenticated) {
      setCurrentPage('login');
    }
  }, [currentPage, isAuthenticated, isLoading]);

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      case 'login':
        return <LoginPage setCurrentPage={setCurrentPage} />;
      case 'signup':
        return <SignupPage setCurrentPage={setCurrentPage} />;
      case 'dashboard':
        return isAuthenticated ? <SurveillanceDashboard setCurrentPage={setCurrentPage} /> : <LoginPage setCurrentPage={setCurrentPage} />;
      default:
        return <HomePage />;
    }
  };

  // Show loading while checking authentication
  if (isLoading) {
    return (
      <div className="min-h-screen bg-black text-white flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
          <p className="text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white overflow-x-hidden">
      <FloatingParticles />
      {currentPage !== 'dashboard' && (
        <Navigation
          currentPage={currentPage}
          setCurrentPage={setCurrentPage}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />
      )}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.3 }}
        >
          {renderPage()}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
